
public class NewVerySmartClass {
  public static void main(String[] args) {
    String importantMessage = "Initialize before use!"; // Local reference variable

    System.out.println("The message length is: " +
                       importantMessage.length());
  }
}