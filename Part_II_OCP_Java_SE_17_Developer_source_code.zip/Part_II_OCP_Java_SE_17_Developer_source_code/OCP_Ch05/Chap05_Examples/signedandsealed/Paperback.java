package signedandsealed;

public final class Paperback extends PrintedBook {                                 // (6)
  public Paperback(String isbn, int pageCount) {
    super(isbn, pageCount);
  }
}