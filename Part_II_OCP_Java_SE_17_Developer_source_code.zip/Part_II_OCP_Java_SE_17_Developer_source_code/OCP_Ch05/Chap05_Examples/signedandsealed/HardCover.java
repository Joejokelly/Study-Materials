package signedandsealed;

public final class HardCover extends PrintedBook {                                 // (5)
  public HardCover(String isbn, int pageCount) {
    super(isbn, pageCount);
  }
}
