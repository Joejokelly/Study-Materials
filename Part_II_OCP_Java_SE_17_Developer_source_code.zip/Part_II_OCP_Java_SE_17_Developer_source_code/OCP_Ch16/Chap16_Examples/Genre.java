// The different genres in music.
public enum Genre {POP, JAZZ, OTHER}