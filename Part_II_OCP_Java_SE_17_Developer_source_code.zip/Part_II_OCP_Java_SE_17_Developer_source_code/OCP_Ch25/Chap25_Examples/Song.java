public class Song extends Composition { }
