@MusicMeta(value="Regional Distribution Policy", maxDuration=600, countries={"GB","US"}) 
public class Composition {
  public void purchase() { }
  @Format 
  public void play() { }  
}