//File: Circus.java
import wizard.pandorasbox.*;

public class Circus {
  Clown performerOne;                    // OK. Simple class name
  wizard.pandorasbox.Clown performerTwo; // OK. Fully qualified class name

//LovePotion moreTLC;                    // Error. Not accessible
//Magic magician;                        // Error. Not accessible
}