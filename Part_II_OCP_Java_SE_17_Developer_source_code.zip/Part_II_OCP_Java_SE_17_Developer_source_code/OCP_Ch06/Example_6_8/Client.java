// File: Client.java

public class Client {
  public static void main(String[] args) {
     pkg1.Superclass1.printState1();
//     pkg1.Subclass1.printState1();
//     pkg1.AnyClass1.printState1();

     pkg2.Subclass2.printState1();
//     pkg2.AnyClass2.printState2();
  }
}